# My Static Website

I am learning how to use GitHub...  
See you at [https://idolinux.com/](https://idolinux.com/)
